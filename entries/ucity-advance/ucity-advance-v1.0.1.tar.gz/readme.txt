Default controls:

A:      X
B:      Z
L:      A
R:      S
Start:  Left shift
Select: Return
Pad:    Arrows

You can reconfigure them by pressing F3, along with other options.
